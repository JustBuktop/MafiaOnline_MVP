using UnityEngine;
using UnityEngine.UIElements;

public class LobbyController : MonoBehaviour
{
    public UIDocument lobbyUIDocument;

    private VisualElement root;
    private Button backButton;
    private Button readyButton;
    private Label rolesList;
    private VisualElement playerGrid;

    void Awake()
    {
        root = lobbyUIDocument.rootVisualElement;

        backButton = root.Q<Button>("back-button");
        readyButton = root.Q<Button>("ready-button");
        rolesList = root.Q<Label>("roles-list");
        playerGrid = root.Q<VisualElement>("player-grid");

        backButton.clicked += OnBack;
        readyButton.clicked += OnReady;
    }

    private void OnBack()
    {
        gameObject.SetActive(false);
        // ������� � ������� ����, ��������:
        // mainMenu.SetActive(true);
    }

    private void OnReady()
    {
        Debug.Log("����� �����");
        // ���� ������ ����������
    }

    public void AddPlayer(string name, int number, Texture2D avatar, bool isReady)
    {
        VisualElement slot = new VisualElement();
        slot.AddToClassList("player-slot");

        var image = new Image { image = avatar };
        image.AddToClassList("player-avatar");

        var label = new Label($"{number}. {name}") { name = "name-label" };
        label.AddToClassList("player-name");

        var status = new Label(isReady ? "�����" : "�������");
        status.AddToClassList(isReady ? "ready" : "waiting");

        slot.Add(image);
        slot.Add(label);
        slot.Add(status);

        playerGrid.Add(slot);
    }
}
